%% 串口回调函数
function ReadFcn_Com2(obj,~)
global snum smax X Y L reset
n = get(obj, 'BytesAvailable');%这里会获得所有缓存区內的数据
%% HEX格式
if reset
if n% 有效读取 防止Matlab延迟进入或误进入
a = fread(obj, n, 'uint8');
end

if(snum>=smax)
    load('music.mat');
    WriteSerial(obj,[0,0,0,0,0,165]); 
    pause(0.5);
    CloseSerial(obj);
    sound(B,44100);
%     set(handles.text7,'String','Finished');
    return;

else
    WriteSerial(obj,[mod(X(snum),256),fix(X(snum)/256),mod(Y(snum),256),fix(Y(snum)/256),L(snum),165]);
    disp(snum);
    snum=snum+1;
%     set(handles.text7,'String',['Progress:',num2str(snum*100/smax),'%']);
end
else
    reset=1;
    WriteSerial(obj,[0,0,0,0,0,165]); 
    pause(0.5);
    CloseSerial(obj);
    return;
end
%% ASC2格式
% if n
% a = fread(obj, n, 'uchar');
% disp(char(a'));
% end
end