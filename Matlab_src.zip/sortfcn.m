function A = sortfcn( x,y )
N=length(x);
A=zeros(2,N);
A(1,1)=x(1);
A(2,1)=y(1);
for i=1:N-1
   d=(x-A(1,i)).^2+(y-A(2,i)).^2;
   [~,j]=min(d);
   A(1,i+1)=x(j);
   A(2,i+1)=y(j);
   x(j)=[];
   y(j)=[];
end

end